package com.example.ejerciciopractico

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ejerciciopractico.R

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                PantallaPrincipal(nombreEstudiante = "Juan Pérez")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaPrincipal(nombreEstudiante: String) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("App Académica") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Logo de la app",
                modifier = Modifier.size(100.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Nombre de la app
            Text(
                text = "App Académica",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )

            // Nombre del estudiante
            Text(
                text = "Estudiante: $nombreEstudiante",
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Tarjetas de información
            TarjetaInfo(icono = Icons.Filled.Person, titulo = "Mi perfil", descripcion = "Ver datos personales")
            Spacer(modifier = Modifier.height(8.dp))
            TarjetaInfo(icono = Icons.Filled.DateRange, titulo = "Horario", descripcion = "Consultar clases del día")
            Spacer(modifier = Modifier.height(8.dp))
            TarjetaInfo(icono = Icons.Filled.Notifications, titulo = "Notificaciones", descripcion = "Avisos académicos")

            Spacer(modifier = Modifier.height(24.dp))

            // Botones
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { /* acción de ejemplo */ }) {
                    Text("Ver notas")
                }
                OutlinedButton(onClick = { /* acción de ejemplo */ }) {
                    Text("Cerrar sesión")
                }
            }
        }
    }
}

@Composable
fun TarjetaInfo(icono: androidx.compose.ui.graphics.vector.ImageVector, titulo: String, descripcion: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icono, contentDescription = titulo, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = titulo, fontWeight = FontWeight.Bold)
                Text(text = descripcion, fontSize = 13.sp)
            }
        }
    }
}